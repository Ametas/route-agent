// fake module source
